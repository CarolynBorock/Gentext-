def test_user():
    return "testing user service"